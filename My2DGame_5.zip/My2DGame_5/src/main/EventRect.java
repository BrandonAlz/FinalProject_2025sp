package main;

import java.awt.*;

public class EventRect extends Rectangle {

    int eventRectDefaultX, eventRectDefaultY;
    boolean eventDone = false;

}
